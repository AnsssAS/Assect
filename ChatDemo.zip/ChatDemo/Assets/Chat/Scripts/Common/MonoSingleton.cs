﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Common
{
    /// <summary>
    /// 
    /// </summary>
    public class MonoSingleton<T> : MonoBehaviour where T : MonoSingleton<T>
    {
        //public static T Instance
        //{
        //    get;
        //    private set;
        //}
        //private void Awake()
        //{
        //    Instance = this as T;
        //} 
        //按需加载
        private static T instance;
        public static T Instance
        {
            get
            {
                if (instance == null)
                {
                    //在场景中查找对象
                    instance = FindObjectOfType<T>();
                    if (instance == null)
                    {
                        //创建游戏对象 附加 脚本对象
                        new GameObject("Singleton of " + typeof(T)).AddComponent<T>();//立即执行Awake
                    }
                    else
                    {
                        instance.Initialized();
                    }
                }
                return instance;
            }
        }

        protected virtual void Initialized()
        {
            DontDestroyOnLoad(gameObject);
        }

        [Tooltip("是否需要跨场景不销毁")]
        public bool isDontDestroy = true;

        //如果管理类自行附加到物体中
        //在Awake中为instance赋值 
        protected void Awake()
        {
            if (isDontDestroy)
            {
                DontDestroyOnLoad(gameObject);
            }
            if (instance == null)
            {
                instance = this as T;
                instance.Initialized();
            }
        }
    }
}