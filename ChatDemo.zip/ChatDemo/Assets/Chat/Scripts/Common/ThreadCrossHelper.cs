﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 
namespace Common
{
    /// <summary>
    /// 
    /// </summary>
    public class ThreadCrossHelper : MonoSingleton<ThreadCrossHelper>
    {
        /// <summary>
        /// 延迟项
        /// </summary> 
        class DelayedItem
        {
            public Action CurrentAction { get; set; }
            public DateTime Time { get; set; }
        }

        private List<DelayedItem> actionList;
        //private List<Action> actionList;
        //private List<float> timeList;

        protected override void Initialized()
        {
            base.Initialized();

            actionList = new List<DelayedItem>(); 
        }

        private void Update()
        { 
            for (int i = actionList.Count - 1; i >= 0; i--)
            {
                //到时间
                if (actionList[i].Time <= DateTime.Now)
                {
                    lock (actionList)
                    {
                        actionList[i].CurrentAction();//执行
                        actionList.RemoveAt(i);//从列表中移除 
                    }
                }
            }
        }
        /// <summary>
        /// 为子线程提供，可以在主线程中执行的方法
        /// </summary>
        /// <param name="action"></param>
        /// <param name="dealy"></param>
        public void ExecuteOnMainThread(Action action, float dealy = 0)
        {
            DelayedItem item = new DelayedItem()
            {
                CurrentAction = action,
                //Time = Time.time + dealy
                Time = DateTime.Now.AddSeconds(dealy)
            };
            lock (actionList)
            {
                actionList.Add(item);
            }
        }
    }
}