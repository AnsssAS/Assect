﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Common
{
    /// <summary>
    /// 变换组件助手类
    /// </summary>
    public static  class TransformHelper
    { 
        /// <summary>
        /// 未知层级，根据名称查找后代元素
        /// </summary>
        /// <param name="currentTF"></param>
        /// <param name="childName"></param>
        /// <returns></returns>
        public static Transform FindChildByName(this Transform currentTF, string childName)
        {
            Transform childTF = currentTF.Find(childName);
            if (childTF != null) return childTF;
            //将问题推迟给子物体
            for (int i = 0; i < currentTF.childCount; i++)
            {
                //在方法体内部，又遇到了相同的问题，所以需要调用自身。
                childTF = FindChildByName(currentTF.GetChild(i), childName);
                if (childTF != null) return childTF;
            }
            return null;
        }
    }
}