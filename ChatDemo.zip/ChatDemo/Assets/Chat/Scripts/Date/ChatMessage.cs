﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using System.Net.Sockets;
using System.Text;
using Common;
using UnityEngine.UI;
using System;
using System.Net;
using UIWidgetsSamples;
using System.Runtime.Serialization.Formatters.Binary;

namespace  NS
{
    ///<summary>
    ///聊天消息
    ///</summary>
    [System.Serializable]//表示类可以被序列化
    public class ChatMessage 
    {
        //消息类型 0 1 2 枚举
        public UDPNetWork Type { get; set; }
        //发送者名称
        public string SenderName { get; set; }
        //消息内容
        public string Content { get; set; }


        //如何把一个对象转字节数组？？？
        //序列化：将对象状态存储到某种介质的过程（场景还原，网络交互）
        //存储介质:磁盘  内存   网络
        //反序列化：将某种介质中的对象转换成C#对象
        public  byte []  ObjectToBytes()
        {
            //1.二进制写入器  往内存流去写  支持跨平台
            //MemoryStream ms = new MemoryStream();
            //BinaryWriter writer = new BinaryWriter(ms);

            //byte[] bys = Encoding.UTF8.GetBytes(SenderName);
            ////值类型  因为大小固定  所以直接Write
            ////引用类型  大小不固定  所以需要写入长度
            //writer.Write(bys.Length);
            ////写入长度
            //writer.Write(bys);
            //写入内容
            //2.序列化
            //使用Using  可以在退出代码块的时候 自动关闭非托管资源
            using (MemoryStream ms = new MemoryStream())
            {
                //内存流
                BinaryFormatter fomatter = new BinaryFormatter();
                //二进制格式化器
                fomatter.Serialize(ms, this);
                //序列化  将当前对象序列化到内存流中                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 

                //byte[] result = ms.ToArray();
                //从内存流中获取字节数组
                return ms.ToArray();
            }
        }
        public static  ChatMessage   BytesToObject(byte [] bytes)
        {
            using (MemoryStream ms = new MemoryStream(bytes))
            {
                //内存流
                BinaryFormatter fomatter = new BinaryFormatter();
                //二进制格式化器
                return fomatter.Deserialize(ms) as ChatMessage;
                //反序列化  将内存流中  中的字节反序列化                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               

            }
            //自动释放资源
        }
    }
}
