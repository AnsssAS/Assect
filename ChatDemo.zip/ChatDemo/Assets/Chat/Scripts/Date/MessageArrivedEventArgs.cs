﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Net;

namespace  NS
{
    ///<summary>
    /// 事件参数类 
    ///</summary>
    public class MessageArrivedEventArgs
    {
        public  ChatMessage Message { get; set; }
        public DateTime DateTime { get; set; }

        public IPEndPoint senderEP { get; set; }

    }
}
