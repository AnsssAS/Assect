﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace  NS
{
    ///<summary>
    /// 消息类型
    ///</summary>
    public enum UDPNetWork
    {
        Online,
        //上线
        Offline,
        //下线
        General
        //普通
    }
}
