﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.Text;
using Common;
using UnityEngine.UI;
using System;
using System.Net;
using UIWidgetsSamples;
using UnityEngine.SceneManagement;

namespace  NS
{
    ///<summary>
    /// 程序入口
    ///</summary>
    public class GameMain : MonoSingleton<GameMain>
    {

        private InputField IPInputField;

        private InputField IPInputField1;
        //点击按钮 ButtonClientEnter初始化客户端服务类
        private void Start()
        {
            transform.FindChildByName("ButtonClientEnter").
                GetComponent<Button>().onClick.AddListener(OnEnterChatScene);
            //获取进入按钮
            transform.FindChildByName("ButtonServerEnter").
                GetComponent<Button>().onClick.AddListener(OnEnterServerScene);
            // InputServerIPForClient
            IPInputField1 = transform.FindChildByName("" +
                "InputServerIPForClient").GetComponent<InputField>();
            IPInputField = transform.FindChildByName("" +
                "InputServerIPForServer").GetComponent<InputField>();
            //获取文本框  拿到IP
        }

        private void OnEnterServerScene()
        {
            UDPServerNetWorkService.Instance.Initialized(IPInputField.text);
            SceneManager.LoadScene("Server");
        }

        //进去聊天室
        private void OnEnterChatScene()
        {
            UDPClientNetWorkService.Instance.Initialized 
                (IPInputField1.text);
            //获取IP  初始化客户都安
            SceneManager.LoadScene("Chat");
            //切换到聊天窗口 加载不删除 
        }

        //加载场景
    }
}
