﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.Text;
using Common;
using UnityEngine.UI;
using System;
using System.Net;
using UIWidgetsSamples;
namespace  NS
{
    ///<summary>
    ///显示信息界面类
    ///</summary>
    public class ChatClient : MonoBehaviour
    {
        private InputField messageInput;

        private InputField nameInput;
        private void Start()
        {
            messageInput = transform.FindChildByName("MessageInput").GetComponent<InputField>();
            nameInput = transform.FindChildByName("NameInput").GetComponent<InputField>();
            transform.FindChildByName("Send").GetComponent<Button>().
                onClick.AddListener(OnSendButtonClick);
            //获取各种组建
            chatview = transform.FindChildByName("ChatView").GetComponent<ChatView>();
            UDPClientNetWorkService.Instance.MessageArrivedEventHandler 
                += OnMessageArrived;
            //注册事件
        }
        //点击调用发送消息的方法
        private void OnSendButtonClick()
        {
            ChatMessage msg = new ChatMessage()
            {
                Type = UDPNetWork.General,
                Content = messageInput.text,
                SenderName = nameInput.text
            };
            UDPClientNetWorkService.Instance.
                SendChatMessage(msg);
        }
        private ChatView chatview;
        private  void  OnMessageArrived(MessageArrivedEventArgs args)
        {
            //注册方法
            //显示消息
            ChatLine line = new ChatLine()
            {
                //事件参数对象赋值？？？？
                Time = args.DateTime,
                Message = args.Message.Content,
                Type = ChatLineType.User,
                UserName=args.Message.SenderName
            };
            chatview.DataSource.Add(line);
            //滚动
            chatview.ScrollRect.verticalNormalizedPosition = 0;
        }
    }
}
