﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Common;
namespace  NS
{
    ///<summary>
    ///
    ///</summary>
    public class ChatServer : MonoBehaviour
    {
        private void Start()
        {
            text = transform.FindChildByName("Text").GetComponent<Text>();
            UDPServerNetWorkService.Instance.MessageArrivedEventHandler
                += OnMessageArrived;
        }
        private Text text;  
        //当服务端收到消息 显示在文本中
        private void OnMessageArrived(MessageArrivedEventArgs obj)
        {
            Debug.Log(obj.Message.Type);
            text.text = string.Format("{0}---{1}", 
                obj.Message.Type, obj.Message.Content);
        }
    }
}
