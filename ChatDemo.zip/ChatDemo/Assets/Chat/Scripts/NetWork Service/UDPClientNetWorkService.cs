﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Common;
using System.Net.Sockets;
using System.Text;
using UnityEngine.UI;
using System.Net;
using UIWidgetsSamples;
using System.Threading;
namespace  NS
{
    ///<summary>
    ///基于UDP协议  客户端网络服务类
    ///</summary>
    public class UDPClientNetWorkService : MonoSingleton<UDPClientNetWorkService>
    {
        //事件参数类  传递信息
        public event Action<MessageArrivedEventArgs> MessageArrivedEventHandler;
        //初始化socket对象  ，由开始界面的Game Main类调用
        private Thread receiverThread;
        //线程
        private UdpClient udpServer;
        public void Initialized(string serverIP)
        {
            
            //加载不删除对象
            udpServer = new UdpClient();
            //客户端发送消息再给终结点
            serverEP = new IPEndPoint(IPAddress.Parse(serverIP), 8989);
            Debug.Log(serverEP.Address);

            //分配IP和端口  没有保存
            udpServer.Connect(serverEP);
            //Connect方法建立默认远程主机使用中指定的值endPoint参数。 
            //一旦建立，无需在每次调用中指定远程主机Send方法。

            receiverThread = new Thread(ReceiveMessage);
            receiverThread.Start();
            //提示上线
            SendChatMessage(new ChatMessage() { Type = UDPNetWork.Online });
        }
        private IPEndPoint serverEP;
        //发送消息  send按钮
        public void SendChatMessage(ChatMessage msg)
        {
            byte[] dgram = msg.ObjectToBytes();
            //获取报文
            udpServer.Send(dgram, dgram.Length);
            //发送需要端口和IP
            
            Debug.Log(msg.Type);
        }
        //接收消息  接收阻塞  线程
        public void ReceiveMessage()
        {
            while (true)
            {
                //接收
                IPEndPoint remote = new IPEndPoint(IPAddress.Any, 0);
                byte[] date = udpServer.Receive(ref remote);
                ChatMessage msg = ChatMessage.BytesToObject(date);
                Debug.Log(msg.Type);
                //引发事件
                if (MessageArrivedEventHandler != null)
                {
                    //线程交叉助手类调用 因为访问UnityAPI
                    ThreadCrossHelper.Instance.ExecuteOnMainThread(() =>
                    {
                        var args = new MessageArrivedEventArgs()
                        {
                            Message = msg,
                            DateTime = DateTime.Now
                        };
                    //创建事件参数类  参数没有赋值？？？
                    MessageArrivedEventHandler(args);
                    //调用方法不需要传参数吗？？？
                });
                }

            }
        }
        //关闭
        public void OnApplicationQuit()
        {
            SendChatMessage(new ChatMessage() { Type = UDPNetWork.Offline });
            receiverThread.Abort();
            udpServer.Close();
        }
    }
}
