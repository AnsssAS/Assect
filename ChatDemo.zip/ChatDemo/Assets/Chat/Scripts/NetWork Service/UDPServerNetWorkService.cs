﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Common;
using System.Net.Sockets;
using System.Text;
using UnityEngine.UI;
using System.Net;
using UIWidgetsSamples;
using System.Threading;
using System;
namespace  NS
{
    ///<summary>
    /// 基于DUP的服务端网络服务类
    ///</summary>
    public class UDPServerNetWorkService : MonoSingleton<UDPServerNetWorkService>
    {
        //客户端列表
        //初始化Socket
        //发送消息
        //接收消息 
        //事件参数类  传递信息
        public event Action<MessageArrivedEventArgs> MessageArrivedEventHandler;
        //初始化socket对象  ，由开始界面的Game Main类调用
        private Thread receiverThread;
        //线程
        private UdpClient udpServer;
        public void Initialized(string serverIP)
        {
            //加载不删除对象
            //客户端发送消息再给终结点
            serverEP = new IPEndPoint(IPAddress.Parse(serverIP), 8989);
            udpServer = new UdpClient(serverEP);

            receiverThread = new Thread(ReceiveMessage);
            receiverThread.Start();


            //注册事件  收到消息的时候执行
            MessageArrivedEventHandler += OnMessageArrived;
        }
        //收到消息的时候分发
        private void OnMessageArrived(MessageArrivedEventArgs obj)
        {
            switch (obj.Message.Type)
            {
                case UDPNetWork.Online:
                    //存列表
                    AddClient(obj.senderEP);
                    break;
                case UDPNetWork.Offline:
                    //移除列表
                    RemoveClient(obj.senderEP);
                    break;
                case UDPNetWork.General:
                    //转发
                    TransmitMessage(obj.Message);
                    break;
            }
        }

        private IPEndPoint serverEP;
        //发送消息  send按钮
        public void SendChatMessage(ChatMessage msg,IPEndPoint remote)
        {
            byte[] dgram = msg.ObjectToBytes();
            //获取报文
            udpServer.Send(dgram, dgram.Length, remote);
            //发送需要端口和IP
        }
        //接收消息  接收阻塞  线程
        public void ReceiveMessage()
        {
            while (true)
            {

                //接收
                IPEndPoint remote = new IPEndPoint(IPAddress.Any, 0);
                byte[] date = udpServer.Receive(ref remote);
                ChatMessage msg = ChatMessage.BytesToObject(date);
                Debug.Log(msg.Type + "adsadad");
                //引发事件
                if (MessageArrivedEventHandler != null)
                {
                    //线程交叉助手类调用 因为访问UnityAPI
                    ThreadCrossHelper.Instance.ExecuteOnMainThread(() =>
                    {
                        var args = new MessageArrivedEventArgs()
                        {
                            Message = msg,
                            DateTime = DateTime.Now,
                            senderEP = remote
                            
                        };
                        Debug.Log(msg + "1");
                    //创建事件参数类  参数没有赋值？？？
                    MessageArrivedEventHandler(args);
                        //调用方法不需要传参数吗？？？
                        Debug.Log(msg + "2");
                    });
                }
            }
        }
        //关闭
        public void OnApplicationQuit()
        {
            receiverThread.Abort();
            udpServer.Close();
        }

        private List<IPEndPoint> allListEP = new List<IPEndPoint>();
        //添加客户端
        public  void AddClient(IPEndPoint clientEP)
        {
            allListEP.Add(clientEP);
        }
        //移除客户端
        public void RemoveClient(IPEndPoint clientEP)
        {
            allListEP.Remove(clientEP);
        }
        //转发消息
        private void  TransmitMessage(ChatMessage msg)
        {
            foreach (var item in allListEP)
            {
                SendChatMessage(msg, item);
                //根据不同端口发送消息
            }
        }
    }
}
