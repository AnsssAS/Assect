﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.Text;
using Common;
using UnityEngine.UI;
using System;
using System.Net;
using UIWidgetsSamples;
namespace  NETWORK
{
    ///<summary>
    /// TCP客户端  发送消息
    ///</summary>
    public class ChatTCPClientTest : MonoBehaviour
    {
        private InputField messageInput;
        //1.创建Socket对象  建立连接
        private void Start()
        {

            var server = FindObjectOfType<ChatTCPServerTest>();
            IPEndPoint ep = new IPEndPoint(IPAddress.Parse(server.serverIP), server.serverPort);
            //创建终结点
             tcpClient = new TcpClient();
            //创建
            tcpClient.Connect(ep);//三次握手 
            messageInput = transform.FindChildByName("MessageInput").GetComponent<InputField>();
            transform.FindChildByName("Send").GetComponent<Button>().onClick.AddListener(OnSendButtonClick);
        }

        private void OnSendButtonClick()
        {
            SendChatMessage(messageInput.text);
        }

        private TcpClient tcpClient;
        //2发送消息
        private void SendChatMessage(string msg)
        {
            //获取网络流
            NetworkStream stream = tcpClient.GetStream();
            byte[] dgramContent = Encoding.UTF8.GetBytes(msg);
            //传入内容
            stream.Write(dgramContent, 0, dgramContent.Length);
            //写入网络流  内容  从那开始发  发的长度
        }
        //3.关闭连接/释放资源
        private void OnApplicationQuit()
        {
            tcpClient.Close();
        }
    }
}
