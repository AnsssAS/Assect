﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.Text;
using Common;
using UnityEngine.UI;
using System;
using System.Net;
using UIWidgetsSamples;
using System.Threading;

namespace  NETWORK
{
    ///<summary>
    /// TCP  接收信息
    ///</summary>
    public class ChatTCPServerTest : MonoBehaviour
    {
        public string serverIP;
        //IP
        public int serverPort;
        //端口
        //1.创建Socket对象
        private ChatView chatView;
        private void Start()
        {
            chatView = transform.FindChildByName("ChatView").
                 GetComponent<ChatView>();
            IPEndPoint ep = new IPEndPoint(IPAddress.Parse(serverIP), serverPort); 
             serverlisten = new TcpListener(ep);
            serverlisten.Start();
            //创建对象并开启监听

             thread = new Thread(ReceiveClient);
            thread.Start();
        }
        private TcpListener serverlisten;
        private Thread thread;
        //2.开启监听
        //3.接收数据  显示
        private  void  ReceiveClient()
        {
            //接收客户端信息  要先连接 如果没有连接 会造成阻塞线程
            TcpClient client = serverlisten.AcceptTcpClient();
            //接收消息
            NetworkStream stream = client.GetStream();
            //读取网络流到容器
            byte[] date = new byte[1024];
            //返回读了多少字节
            //Read读取消息 如果没有读取到  线程阻塞
            //如果有多个客户端 要循环接收  将读到的信息放到线程中
            int count;
            while ((count=stream.Read(date,0,date.Length))>0)//count为0  表示客户端下线
            {
                //解析
                string msg = Encoding.UTF8.GetString(date);
                ThreadCrossHelper.Instance.ExecuteOnMainThread(() =>
                { ShowMessage(msg); });
            }
            client.Close();//关闭Socket对象 自动释放流
            //显示数据之前  如果有多个客户端？？？
        }
        public void ShowMessage(string msg)
        {
            chatView.DataSource.Add(new ChatLine()
            {
                UserName = "LXY",
                Message = msg,
                Time = DateTime.Now,
                Type = ChatLineType.User,
            }
                );
        }
        //4.关闭
        public void OnApplicationQuit()
        {
            thread.Abort();
            serverlisten.Stop();           
        }
    }
}
