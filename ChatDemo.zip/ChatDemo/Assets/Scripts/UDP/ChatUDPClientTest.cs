﻿using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using UnityEngine;
using Common;
using UnityEngine.UI;
using System;
using System.Net;
using UIWidgetsSamples;
namespace  NS
{
    ///<summary>
    ///通过UDP协议，发送消息
    ///</summary>
    public class ChatUDPClientTest : MonoBehaviour
    {
        //1.创建Socket对象
        private UdpClient udpClient;
        //文本框
        private InputField messageInput;
        private void Start()
        {
            //IP,Port,协议
            var server=  FindObjectOfType<ChatUDPServerTest>();
             serverEP = new IPEndPoint
                (IPAddress.Parse(server.serverIP), server.serverPort);
            //通过无参构造函数创建的Socket，自动分配IP和端口
             udpClient = new UdpClient();
            messageInput = transform.FindChildByName("MessageInput").GetComponent<InputField>();
            transform.FindChildByName("Send").GetComponent<Button>().onClick.AddListener(OnSendButtonClick);
        }
        private IPEndPoint serverEP;
        private void OnSendButtonClick()
        {
            SendChatMessage(messageInput.text);
            //传消息
        }

        //2.Send
        public void  SendChatMessage(string meg)
        {
            //            编码
            //string=》   byte []
           byte []  dgramContent=  Encoding.UTF8.GetBytes(meg);
            //dgram  报文  报文的长度
           udpClient.Send(dgramContent, dgramContent.Length,serverEP);
            //发送需要IP和端口
            udpClient.Connect(serverEP);
        }

        //3.Close
        public void OnApplicationQuit()
        {
            udpClient.Close();
            //关闭非托管资源
        }
    }
}
