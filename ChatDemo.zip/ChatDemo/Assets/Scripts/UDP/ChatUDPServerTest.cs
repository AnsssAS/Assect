﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;
using System.Text;
using UnityEngine;
using Common;
using UnityEngine.UI;
using System;
using System.Net;
using UIWidgetsSamples;
using System.Threading;

namespace  NS
{
    ///<summary>
    ///
    ///</summary>
    public class ChatUDPServerTest : MonoBehaviour
    {
        public string serverIP;
        //IP地址
        public int serverPort;
        //端口
        //1.创建Socket对象 IP Port
        private Thread thread;
        public void Start()
        {
            chatView = transform.FindChildByName("ChatView").
                GetComponent<ChatView>();
            //给端口和IP
            //构建终结点  IP和一个端口
            IPEndPoint localEP = new 
                IPEndPoint(IPAddress.Parse(serverIP), serverPort);
            udpServic = new UdpClient(localEP);


             thread = new Thread(ReceiveMessage);
             thread.Start();
        }
        private UdpClient udpServic;
        private  void  ReceiveMessage()
        {
            while (true)
            {

                IPEndPoint remote = new
                    IPEndPoint(IPAddress.Any, 0);
                //创建任意终结点
                //ref 地址传递
                byte[] date = udpServic.Receive(ref remote);
                //Receive接收消息  如果没有收到消息 线程阻塞  放在线程中
                string msg = Encoding.UTF8.GetString(date);
                //获取的客户都安信息
                Debug.Log(remote.Address + "===" + remote.Port);
                //如果接受到客户端的消息.,会把任意终结点修改为客户端的终结点
                ThreadCrossHelper.Instance.ExecuteOnMainThread(() => 
                { ShowMessage(msg); });
                
            }
        }
        private ChatView chatView;
        public void  ShowMessage(string msg)
        {
            chatView.DataSource.Add(new ChatLine()
            {
                UserName = "LXY",
                Message = msg,
                Time = DateTime.Now,
                Type = ChatLineType.User,                
            }
                );
        }
        private void OnApplicationQuit()
        {
            udpServic.Close();
            //关闭socket
            thread.Abort();
            //关闭线程
        }
    }
    
}
