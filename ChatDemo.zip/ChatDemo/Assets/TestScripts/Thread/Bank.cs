﻿using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

/// <summary>
/// 银行
/// </summary>
public class Bank
{
    private static int money = 1;

    private static object locker = new object();
    public static void GetMoney(int val)
    {
        // 0  -1    -2  
        //锁的是流程
        //目的：建立一个临界区(同一时刻只能由一个线程访问)
        lock (locker)//判断同步块索引是否为 -1
        {//如果是则进入临界区，修改同步块索引为0；
            //否则等待。
            if (money >= val)
            {
                Thread.Sleep(1000);//睡眠1秒，用于模拟取钱过程。 
                money -= val;
                Debug.Log("取钱成功." + money);
            }
            else
            {
                Debug.Log("取钱失败." + money);
            }
        }
    }
}
