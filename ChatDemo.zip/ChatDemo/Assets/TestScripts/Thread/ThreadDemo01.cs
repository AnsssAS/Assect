﻿using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

/// <summary>
/// 线程基础：创建、开启、关闭、暂停。
/// </summary>
public class ThreadDemo01 : MonoBehaviour 
{ 
    private ManualResetEvent manual;
    private Thread thread01;
    //执行脚本生命周期的线程，称之为"主线程"。
    //直接在脚本生命周期中中调用的方法，也是由主线程调度的。
    private void Start()
    {
        //信号灯
        manual = new ManualResetEvent(false);

        //Fun1();//主线程调度 

        //1.创建线程对象
        //public delegate void ThreadStart();
        //public delegate void ParameterizedThreadStart(object obj);
        thread01 = new Thread(Fun1); 

        Thread thread02 = new Thread(Fun2);

        //Thread thread01 = new Thread(()=> {
        //    Fun3(2);
        //});

        //2.开启线程
        thread01.Start(); 
        //thread02.Start(2);

        //通过线程池创建线程
        //public delegate void WaitCallback(object state);
        ThreadPool.QueueUserWorkItem(Fun2, 3);

        ThreadPool.QueueUserWorkItem(o=> {
            Fun1();
        });
    } 

    private void Fun1()
    {
        for (int i = 0; true; i++)
        {
            //(线程)等一下
            manual.WaitOne();
            //if (条件)
            //    return;
            print("01：---"+i);
            Thread.Sleep(1000);//线程睡眠1秒 
        }
    } 
    private void Fun2(object n)
    {
        int num = (int)n;
        for (int i = 0; i < num; i++)
        {
            print("02：---" + i);
            Thread.Sleep(1000);//线程睡眠1秒 
        }
    }
    private void Fun3(int n)
    { 
        for (int i = 0; i < n; i++)
        {
            print(i);
            Thread.Sleep(1000);//线程睡眠1秒 
        }
    }

    private void OnGUI()
    {
        if (GUILayout.Button("暂停（红灯）"))
        {
            manual.Reset(); 
        }
        if (GUILayout.Button("通行（绿灯）"))
        {
            manual.Set();
        }
    }

    private void OnApplicationQuit()
    {
        //关闭线程
        thread01.Abort();
    }
}
