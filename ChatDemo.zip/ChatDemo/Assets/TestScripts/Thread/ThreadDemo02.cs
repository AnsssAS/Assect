﻿using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

/// <summary>
/// 
/// </summary>
public class ThreadDemo02 : MonoBehaviour 
{
    private void Start()
    {
        //主线程调度
        //Bank.GetMoney(1);

        //子线程调度
        ThreadPool.QueueUserWorkItem(o => Bank.GetMoney(1));
    }
}
