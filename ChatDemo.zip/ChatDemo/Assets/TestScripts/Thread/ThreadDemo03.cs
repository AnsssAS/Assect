﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 
/// </summary>
public class ThreadDemo03 : MonoBehaviour 
{
    public int second = 120;
    private Text txtTimer;
    private Thread thread;
    private void Start()
    {
        txtTimer = GetComponent<Text>();

        thread = new Thread(Timer);
        thread.Start();
    }

    //private void Update()
    //{
    //    //如果到了xxx时间
    //    txtTimer.text = "01:57";
    //}

    private Action action;

    private void Timer()
    {
        while (second > 0)
        {
            
            //异常：在子线程中，访问了Unity API.
            //txtTimer.text = string.Format("{0:d2}:{1:d2}", second / 60, second % 60);
            //将方法绑定到委托
            //action = () =>
            //{
            //    txtTimer.text = string.Format("{0:d2}:{1:d2}", second / 60, second % 60);
            //}; 
            //通过线程交叉访问助手调度
            //ThreadCrossHelper.Instance.ExecuteOnMainThread(() => {
            //    second--;
            //    txtTimer.text = string.Format("{0:d2}:{1:d2}", second / 60, second % 60);
            //},3);
            //Thread.Sleep(1000);
        }
    }

    private void Update()
    {
        //调用委托 执行绑定的方法
        if (action != null)
        {
            action();
            action = null;
        }
    }

    private void OnApplicationQuit()
    {
        thread.Abort();
    }
}
