﻿using UnityEditor;

namespace UIWidgets
{
	//[CanEditMultipleObjects]
	//[CustomEditor(typeof(TreeView), true)]
	public class TreeViewEditor : TreeViewCustomEditor
	{
	}
}