﻿using UnityEditor;
using UIWidgets;

namespace UIWidgetsSamples
{
	// No more required
	[CanEditMultipleObjects]
	//[CustomEditor(typeof(ListViewCustomSample), true)]
	public class ListViewCustomSampleEditor : ListViewCustomEditor
	{
	}
}