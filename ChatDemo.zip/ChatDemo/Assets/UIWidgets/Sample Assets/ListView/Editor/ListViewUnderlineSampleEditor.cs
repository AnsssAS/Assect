﻿using UnityEditor;
using UIWidgets;

namespace UIWidgetsSamples
{
	// No more required
	[CanEditMultipleObjects]
	//[CustomEditor(typeof(ListViewUnderlineSample), true)]
	public class ListViewUnderlineSampleEditor : ListViewCustomEditor
	{
	}
}