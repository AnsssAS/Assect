﻿using UIWidgets;

namespace UIWidgetsSamples {
	public class ListViewNoColoring : ListView {
		protected override void HighlightColoring(ListViewStringComponent component)
		{
		}

		protected override void SelectColoring(ListViewStringComponent component)
		{
		}
		
		protected override void DefaultColoring(ListViewStringComponent component)
		{
		}
	}
}
