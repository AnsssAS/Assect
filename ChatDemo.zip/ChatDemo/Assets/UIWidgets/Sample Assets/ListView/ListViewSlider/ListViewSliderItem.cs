﻿using UnityEngine;

namespace UIWidgetsSamples {
	
	[System.Serializable]
	public class ListViewSliderItem {
		[SerializeField]
		public int Value;
	}
}