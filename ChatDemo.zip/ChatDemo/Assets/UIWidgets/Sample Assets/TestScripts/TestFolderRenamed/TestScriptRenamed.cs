﻿using UnityEngine;
using System.Collections;

namespace UIWidgetsSamples {
	public class TestScriptRenamed {
	}
}