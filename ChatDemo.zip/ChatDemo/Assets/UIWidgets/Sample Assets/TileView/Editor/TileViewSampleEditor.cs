﻿using UnityEditor;
using UIWidgets;

namespace UIWidgetsSamples
{
	//[CanEditMultipleObjects]
	//[CustomEditor(typeof(TileViewSample), true)]
	public class TileViewSampleEditor : TileViewEditor
	{
	}
}