﻿using UnityEditor;
using UIWidgets;

namespace UIWidgetsSamples
{
	// No more used
	//[CanEditMultipleObjects]
	//[CustomEditor(typeof(TreeViewSample), true)]
	public class TreeViewSampleEditor : TreeViewCustomEditor
	{
	}
}