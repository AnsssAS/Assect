﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace UIWidgets {
	/// <summary>
	/// Tab button.
	/// </summary>
	public class TabButton : Button {
	}
}